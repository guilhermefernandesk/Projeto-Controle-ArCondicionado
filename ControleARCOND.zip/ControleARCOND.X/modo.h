
#ifndef MODO_H
#define	MODO_H

void modo (int m);


#endif	/* MODO_H */

