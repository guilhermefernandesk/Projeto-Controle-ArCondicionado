
#ifndef DESENHO_H
#define	DESENHO_H

  void desenhoInit(void);
  void desenhoOn (void);
  void desenhoOff (void);

#endif	/* DESENHO_H */

