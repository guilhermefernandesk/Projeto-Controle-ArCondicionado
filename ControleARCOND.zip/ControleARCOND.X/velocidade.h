#ifndef VELOCIDADE_H
#define	VELOCIDADE_H

void velocidade (int vel);



#endif	/* VELOCIDADE_H */

